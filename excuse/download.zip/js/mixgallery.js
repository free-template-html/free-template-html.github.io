$(document).on('ready', function() {
  // Start mixitup
  $('#portfolio-items').mixItUp();
});